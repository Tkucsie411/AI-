// 定義 goToPage1 函數，用於處理按鈕跳轉邏輯
function goToPage1() {
  // 導向到 page1.html
  window.location.href = "page1/page1.html";
}